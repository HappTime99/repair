<?php
    session_start();
    if(!isset($_SESSION['userid'])){
        header("Location: login.php");
    }else{
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

    <?php   
        include('include/menu.php');
        include('include/linkjs.php');
        include('include/linkcss.php');
        include('repair_function.php');
        
        if(isset($_GET['id'])){
            $userid = $_GET['id'];
            $del = new Repair();
            $sql =$del->delete($userid);
            if($sql) {
                echo "<script>";
                echo "Swal.fire({
                    icon: 'success',
                    title: 'ลบข้อมูลเสร็จเรียบร้อยแล้วครับ',
                    showConfirmButton: false,
                    timer: 2000
                }).then((result ) => {
                    if(result.isDismissed){
                        window.location.href = 'repair_view.php';
                    }
                  });";
                echo "</script>";
            }
        }
        
        
        
    ?>
    <section class="home-section">
    <i class='bx bx-menu' ></i>
    <div class="container-fluid"> 
    <h1 class="text-center mt-3">ข้อมูลแจ้งซ่อม</h1>
    <hr>
    
    
    <a href="repair_insert.php" class="btn btn-warning">เพิ่ม</a>
    <table class="table">
       <thead>
           <tr>
               <th>#</th>
               <th>ชื่อ</th>
               <th>นามสกุล</th>
               <th>ชุด</th>
               <th>รายละเอียด</th>
               <th>วันที่แจ้งซ่อม</th>
               <th>สถานะ</th>
               <th>จัดการ</th>
           </tr>
       </thead>
       <tbody>
            <?php 
                $fetdata =new Repair();
                $sql = $fetdata->fetchdata();
                foreach($sql as $row){

            ?>
           <tr>
                <td><?php echo $row['id'];?></td>
                <td><?php echo $row['fname'];?></td>
                <td><?php echo $row['lname'];?></td>
                <td><?php echo $row['pset'];?></td>
                <td><?php echo $row['pdetails'];?></td>
                <td><?php echo $row['mdate'];?></td>
                <td>
                    <?php
                        $st = '' ;
                        if($row['status_id']== 0){
                            $st = "กำลังดำเนินการซ่อม";
                        }elseif ($row['status_id']==1){
                            $st = "ซ่อมเสร็จแล้ว";
                        }
                        elseif($row['status_id']==2){
                            $st = "จัดส่งทางไปรษณีย์";
                        }
                        elseif($row['status_id']==3){
                            $st = "อยู่ระหว่างการส่งไปรษณีย์";
                        }
                        else{
                            $st = "ลูกค้ารับสินค้าแล้ว";
                        }
                        echo $st ;
                    ?>
                </td>
                <td class="tex-center"><a href="repair_edit.php?id=<?php echo $row['id'];?>" class="btn btn-danger"> <i class="fas fa-edit"></i>แก้ไข</a>
                <a href="repair_view.php?id=<?php echo $row['id'];?>" class="btn btn-info"> <i class="fas fa-trash-alt"></i> ลบ</a>
                </td>
           </tr>
            <?php } ?>         
       </tbody>
            
    </table>
    </div>            
    </section>
    <script>
        $(document).ready( function () {
              $('.table').DataTable();
          } );
    </script> 
    <script>
  let arrow = document.querySelectorAll(".arrow");
  for (var i = 0; i < arrow.length; i++) {
    arrow[i].addEventListener("click", (e)=>{
   let arrowParent = e.target.parentElement.parentElement;//selecting main parent of arrow
   arrowParent.classList.toggle("showMenu");
    });
  }
  let sidebar = document.querySelector(".sidebar");
  let sidebarBtn = document.querySelector(".bx-menu");
  console.log(sidebarBtn);
  sidebarBtn.addEventListener("click", ()=>{
    sidebar.classList.toggle("close");
  });
  </script>
</body>
<?php include("include/footer.php"); ?>

</html>
<?php } ?>