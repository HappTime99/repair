<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php   
        include('include/menu.php');
        include('include/linkjs.php');
        include('include/linkcss.php');
        include('customer_function.php');
        
        //insert
        if(isset($_POST['insert'])){
            $customer_name = $_POST['customer_name'];
            $customer_surname = $_POST['customer_surname'];
            $customer_tel = $_POST['customer_tel'];
            $customer_address = $_POST['customer_address'];
            
        
            $insert = new Customer();
            $sql = $insert->insert($customer_name,$customer_surname,$customer_tel,$customer_address);
            //echo $sql ; exit();
            if($sql) {
                echo "<script>";
                echo "Swal.fire({
                    icon: 'success',
                    title: 'เพิ่มข้อมูลเสร็จเรียบร้อยแล้วครับ',
                    showConfirmButton: false,
                    timer: 2000
                }).then((result ) => {
                    if(result.isDismissed){
                        window.location.href = 'customer_view.php';
                    }
                  });";
                echo "</script>";
            }else{
                echo "<script>";
                echo "Swal.fire({
                    icon: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong!',
                  });";
                echo "</script>";
            }      
        }

    ?>

    <section class="home-section">
    <i class='bx bx-menu' ></i>
  
    <h1 class="text-center mt-3">เพิ่มข้อมูลลูกค้า</h1>
    <hr>
    
    <form action="" method="post">
        <div class="container">
            <div class="mb-4 row">
                <label for="" class="col-sm-2 col-form-label">ชื่อ</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" name="customer_name"  placeholder="กรุณากรอกชื่อผู้แจ้ง" require>
                </div>
            </div>

            <div class="mb-4 row">
                <label for="" class="col-sm-2 col-form-label">นามสกุล</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" name="customer_surname" placeholder="กรุณากรอกนามสกุลผู้แจ้ง"   require>
                </div>
            </div>

            <div class="mb-4 row">
                <label for="" class="col-sm-2 col-form-label">เบอร์โทร</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" name="customer_tel" placeholder="กรุณากรอกเบอร์โทรผู้แจ้ง"   require>
                </div>
            </div>

            <div class="mb-4 row">
                <label for="" class="col-sm-2 col-form-label">ที่อยู่</label>
                <div class="col-sm-10">
                   <textarea  rows="4" name="customer_address" class="form-control" placeholder="กรุณากรอกรายละเอียด" require></textarea>
                </div>
            </div>


            <div class="text-center">
                <button type="submit" class="btn btn-success" name="insert" >ตกลง</button>
                <a href="customer_view.php" class="btn btn-secondary">ย้อนกลับ</a>
            </div>
    
        </div>
    </form>

    </section>

    <script>
  let arrow = document.querySelectorAll(".arrow");
  for (var i = 0; i < arrow.length; i++) {
    arrow[i].addEventListener("click", (e)=>{
   let arrowParent = e.target.parentElement.parentElement;//selecting main parent of arrow
   arrowParent.classList.toggle("showMenu");
    });
  }
  let sidebar = document.querySelector(".sidebar");
  let sidebarBtn = document.querySelector(".bx-menu");
  console.log(sidebarBtn);
  sidebarBtn.addEventListener("click", ()=>{
    sidebar.classList.toggle("close");
  });
  </script>
</body>
<?php include("include/footer.php"); ?>
</html>