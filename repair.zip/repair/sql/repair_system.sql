-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 12, 2022 at 09:44 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `repair_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `customer_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `customer_surname` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `customer_tel` int(20) NOT NULL,
  `customer_address` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `customer_name`, `customer_surname`, `customer_tel`, `customer_address`) VALUES
(1, 'แสงรุ้ง', 'วีรกิล', 889487332, '2 ถนน จันทน์ แขวง ทุ่งวัดดอน เขต สาทร กรุงเทพมหานคร 10122'),
(2, 'พิศมัย', 'แววงาม', 889134355, '1150 หมู่9 ซอยสุขสวัสดิ์78แยก19 ถนนสุขสวัสดิ์ ตำบลบางจาก อำเภอพระประแดง สมุทรปราการ 10180'),
(3, 'แสงจันทน์', 'ราตรี', 992845623, 'สุขสวัสดิ์ 76 ลัดหลวง อำเภอพระประแดง สมุทรปราการ 10130'),
(4, 'วิลักษณ์', 'ทองสุข', 983561234, 'เลขที่ 1 ถนน เจริญราษฎร์ แขวง ทุ่งวัดดอน เขต สาทร กรุงเทพมหานคร 10120'),
(5, 'พรนภา', 'แสงอรุณเลิศ', 991234567, '777/3, 130 ซอย ลาดพร้าว 130/1 Khlongchan, เขตบางกะปิ');

-- --------------------------------------------------------

--
-- Table structure for table `parcel`
--

CREATE TABLE `parcel` (
  `parcel_id` int(11) NOT NULL,
  `fname` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `lname` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ptel` int(50) NOT NULL,
  `paddress` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `mdate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `parcel`
--

INSERT INTO `parcel` (`parcel_id`, `fname`, `lname`, `ptel`, `paddress`, `mdate`) VALUES
(1, 'แสงรุ้ง', 'วีรกิล', 889487332, '2 ถนน จันทน์ แขวง ทุ่งวัดดอน เขต สาทร กรุงเทพมหานคร 10122', '2021-11-13 18:33:02'),
(2, 'พิศมัย', 'แววงาม', 889134355, '1150 หมู่9 ซอยสุขสวัสดิ์78แยก19 ถนนสุขสวัสดิ์ ตำบลบางจาก อำเภอพระประแดง สมุทรปราการ 10180', '2021-12-20 14:35:07'),
(3, 'แสงจันทน์', 'ราตรี', 992845623, 'สุขสวัสดิ์ 76 ลัดหลวง อำเภอพระประแดง สมุทรปราการ 10130', '2021-12-21 15:20:00');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `id` int(11) NOT NULL,
  `fname` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `lname` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `pset` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `pnumber` int(11) NOT NULL,
  `payment` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`id`, `fname`, `lname`, `pset`, `pnumber`, `payment`) VALUES
(1, 'แสงรุ้ง', 'วีรกิล', 'ชุดเดรส', 2, 1000),
(2, 'พิศมัย', 'แววงาม', 'ชุดแต่งงาน', 1, 1000),
(3, 'แสงจันทน์', 'ราตรี', 'ชุดราตรี', 2, 1700);

-- --------------------------------------------------------

--
-- Table structure for table `repair`
--

CREATE TABLE `repair` (
  `id` int(11) NOT NULL,
  `fname` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `lname` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `pset` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `pdetails` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status_id` int(5) NOT NULL DEFAULT 1,
  `mdate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `repair`
--

INSERT INTO `repair` (`id`, `fname`, `lname`, `pset`, `pdetails`, `status_id`, `mdate`) VALUES
(1, 'แสงรุ้ง', 'วีรกิล', 'ชุดเดรส', 'ช่วงสะโพสหลวม ปรับเข้าให้พอดีตัว', 0, '2021-12-17 09:31:26'),
(2, 'พิศมัย ', 'แววงาม', 'ชุดแต่งงาน', 'ชุดแต่งงานสีครีม เอว และสะโพสหลวมเก็บเข้าให้พอดีตัว ติดผ้าลูกไม้รอบเอว\r\n', 1, '2021-12-17 09:31:57'),
(3, 'แสงจันทน์', 'ราตรี', 'ชุดราตรี', 'ชุดราตรีที่เรียบเกิน นำผ้าลูกไม้มาเสริมที่ไหล่ ทำโบว์ติดด้านหลังเอว เพื่อให้ดูเก๋ขึ้น', 0, '2021-12-21 15:24:47');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `surename` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ptel` int(20) NOT NULL,
  `paddress` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `category_user` int(5) NOT NULL DEFAULT 1,
  `pusername` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ppassword` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `surename`, `ptel`, `paddress`, `category_user`, `pusername`, `ppassword`) VALUES
(1, 'ยุทธดี', 'มีชัย', 889183953, 'หมู่ 4 ซ. สุขสวัสดิ์ 66 กรุงเทพมหานคร อำเภอพระประแดง สมุทรปราการ 10130', 0, 'pimpa', 'f103c746a1066f35b166fd325c87143a'),
(2, 'ส้มโอ', 'อร่อยดี', 994325678, 'หมู่ 6 39/264 ซอย 121 ประชาอุทิศ แขวง ทุ่งครุ เขตทุ่งครุ กรุงเทพมหานคร', 0, 'somdee', '1dcaa9c77ce0b51440269abe832b7ea6'),
(3, 'วันดี', 'สุขใจ', 983124678, '21 อาคารอรกานต์ 10330 10330', 0, 'wandee', '86532e78b2119438cee97f4987c30323');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `parcel`
--
ALTER TABLE `parcel`
  ADD PRIMARY KEY (`parcel_id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `repair`
--
ALTER TABLE `repair`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `parcel`
--
ALTER TABLE `parcel`
  MODIFY `parcel_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `repair`
--
ALTER TABLE `repair`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
