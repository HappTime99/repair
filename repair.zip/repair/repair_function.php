<?php
    include('include/connect.php');

    class Repair{
        public function fetchdata(){
            global $conn;
            $sql = mysqli_query($conn,"SELECT * FROM repair");
            return $sql ;
        }
        public function insert($fname,$lname,$pset,$pdetails,$status_id){
            global $conn;
            $sql = mysqli_query($conn,"INSERT INTO repair(fname,lname,pset,pdetails,status_id) 
            VALUES('$fname','$lname','$pset','$pdetails','$status_id')");
            return $sql;
        }
        public function fetchonerecord($userid){
            global $conn;
            $sql = mysqli_query($conn,"SELECT * FROM repair WHERE id = '$userid'");
            return $sql;
        }
        public function update($fname,$lname,$pset,$pdetails,$status_id,$userid){
            global $conn;
            $sql = mysqli_query($conn,"UPDATE repair SET
            fname = '$fname',
            lname = '$lname',
            pset = '$pset',
            pdetails = '$pdetails',
            status_id = '$status_id'
            WHERE id = '$userid'");
            return $sql;
        }
        
        public function delete($userid){
            global $conn;
            $sql = mysqli_query($conn,"DELETE FROM repair  WHERE id = '$userid'");
            return $sql;
        }
    }
?>