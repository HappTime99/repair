<?php
    include('include/connect.php');

    class Customer{
        public function fetchdata(){
            global $conn;
            $sql = mysqli_query($conn,"SELECT * FROM customer");
            return $sql;
        }
        public function insert($customer_name,$customer_surname,$customer_tel,$customer_address){
            global $conn;
            $sql = mysqli_query($conn,"INSERT INTO customer(customer_name,customer_surname,customer_tel,customer_address) 
            VALUES('$customer_name','$customer_surname','$customer_tel','$customer_address')");
            return $sql;
        }
        public function fetchonerecord($userid){
            global $conn;
            $sql = mysqli_query($conn,"SELECT * FROM customer WHERE id = '$userid'");
            return $sql;
        }
        public function update($customer_name,$customer_surname,$customer_tel,$customer_address,$userid){
            global $conn;
            $sql = mysqli_query($conn,"UPDATE customer SET
            customer_name = '$customer_name',
            customer_surname = '$customer_surname',
            customer_tel = '$customer_tel',
            customer_address = '$customer_address'
            WHERE id = '$userid'");
            return $sql;
        }
        
        public function delete($userid){
            global $conn;
            $sql = mysqli_query($conn,"DELETE FROM customer  WHERE id = '$userid'");
            return $sql;
        }
    }
?>