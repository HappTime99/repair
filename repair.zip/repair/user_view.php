<?php
    session_start();
    if(!isset($_SESSION['userid'])){
        header("Location: login.php");
    }else{
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

    <?php   
        include('include/menu.php');
        include('include/linkjs.php');
        include('include/linkcss.php');
        include('user_function.php');
        
        if(isset($_GET['id'])){
            $userid = $_GET['id'];
            $del = new User();
            $sql =$del->delete($userid);
            if($sql) {
                echo "<script>";
                echo "Swal.fire({
                    icon: 'success',
                    title: 'ลบข้อมูลเสร็จเรียบร้อยแล้วครับ',
                    showConfirmButton: false,
                    timer: 2000
                }).then((result ) => {
                    if(result.isDismissed){
                        window.location.href = 'user_view.php';
                    }
                  });";
                echo "</script>";
            }
        }
        
        
        
    ?>
    <section class="home-section">
    <i class='bx bx-menu' ></i>
    <div class="container-fluid">
    <h1 class="text-center mt-3">ข้อมูลผู้ใช้งาน</h1>
    <hr>
    
    
    <a href="user_insert.php" class="btn btn-warning">เพิ่ม</a>
    <table class="table">
       <thead>
           <tr>
               <th>#</th>
               <th>ชื่อ</th>
               <th>นามสกุล</th>
               <th>เบอร์โทร</th>
               <th>ที่อยุ่</th>
               <th>ประเภทผู้ใช้งาน</th>
               <th>ชื่อผู้ใช้</th>
               <th>รหัสผู้ใช้งาน</th>
               <th>จัดการ</th>
           </tr>
       </thead>
       <tbody>
            <?php 
                $fetdata =new User();
                $sql = $fetdata->fetchdata();
                foreach($sql as $row){

            ?>
           <tr>
                <td><?php echo $row['id'];?></td>
                <td><?php echo $row['name'];?></td>
                <td><?php echo $row['surename'];?></td>
                <td><?php echo $row['ptel'];?></td>
                <td><?php echo $row['paddress'];?></td>
                <td>
                    <?php
                        $st = '' ;
                        if($row['category_user']== 1){
                            $st = "ADMIN";
                        }else{
                            $st = "EMPLOYEE";
                        }
                        echo $st ;
                    ?>
                </td>
                <td><?php echo $row['pusername'];?></td>
                <td><?php echo $row['ppassword'];?></td>
                <td class="tex-center"><a href="user_edit.php?id=<?php echo $row['id'];?>" class="btn btn-danger"> <i class="fas fa-edit"></i>แก้ไข</a>
                <a href="user_view.php?id=<?php echo $row['id'];?>" class="btn btn-info"> <i class="fas fa-trash-alt"></i> ลบ</a>
                </td>
           </tr>
            <?php } ?>         
       </tbody>
            
    </table>
    </div>
    
                    
    </section>
    <script>
  let arrow = document.querySelectorAll(".arrow");
  for (var i = 0; i < arrow.length; i++) {
    arrow[i].addEventListener("click", (e)=>{
   let arrowParent = e.target.parentElement.parentElement;//selecting main parent of arrow
   arrowParent.classList.toggle("showMenu");
    });
  }
  let sidebar = document.querySelector(".sidebar");
  let sidebarBtn = document.querySelector(".bx-menu");
  console.log(sidebarBtn);
  sidebarBtn.addEventListener("click", ()=>{
    sidebar.classList.toggle("close");
  });
  </script>
</body>
<?php include("include/footer.php"); ?>
    <script>
        $(document).ready( function () {
              $('.table').DataTable();
          } );
    </script> 
</html>
<?php } ?>