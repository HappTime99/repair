<!DOCTYPE html>
<!-- Created by CodingLab |www.youtube.com/CodingLabYT-->
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <!--<title> Drop Down Sidebar Menu | CodingLab </title>-->
    <link rel="stylesheet" href="include/menu.css">
    <!-- Boxiocns CDN Link -->
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
  <div class="sidebar close">
    <div class="logo-details">
      <i class='bx bx-wrench'></i>
      <span class="logo_name">System Repair</span>
    </div>
    <ul class="nav-links">
      <li>
        <a href="index.php">
          <i class='bx bx-grid-alt' ></i>
          <span class="link_name">หน้าหลัก</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="#">หน้าหลัก</a></li>
        </ul>
      </li>
      
      
      <li>
        <a href="user_view.php">
          <i class='bx bx-user' ></i>
          <span class="link_name">ผู้ใช้งาน</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="#">ผู้ใช้งาน</a></li>
        </ul>
      </li>
      <li>
        <a href="customer_view.php">
          <i class='bx bx-message-rounded ' ></i>
          <span class="link_name">ลูกค้า</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="#">ลูกค้า</a></li>
        </ul>
      </li>
      
      <li>
        <a href="repair_view.php">
          <i class='bx bx-pencil' ></i>
          <span class="link_name">แจ้งซ่อม</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="#">แจ้งซ่อม</a></li>
        </ul>
      </li>

      <li>
        <a href="payment_view.php">
          <i class='bx bx-credit-card'></i>
          <span class="link_name">ชำระเงิน</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="#">ชำระเงิน</a></li>
        </ul>
      </li>

      <li>
        <a href="parcel_view.php">
          <i class='bx bx-box' ></i>
          <span class="link_name">จัดส่งพัสดุ</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="#">จัดส่งพัสดุ</a></li>
        </ul>
      </li>

      


      <li>
        <div class="iocn-link">
          <a href="#">
            <i class='bx bx-bookmark' ></i>
            <span class="link_name">รายงานผล</span>
          </a>
          <i class='bx bxs-chevron-down arrow' ></i>
        </div>
        <ul class="sub-menu">
          <li><a class="link_name" href="#">รายงานผล</a></li>
          <li><a href="report_user.php">ผู้ใช้งาน</a></li>
          <li><a href="report_customer.php">ลูกค้า</a></li>
          <li><a href="report_repair.php">แจ้งซ่อม</a></li>
          <li><a href="report_parcel.php">จัดส่งพัสดุ</a></li>
          <li><a href="report_payment.php">ชำระเงิน</a></li>
        </ul>
      </li>
      
  <li>
    <div class="profile-details">
      <div class="profile-content">
        <img src="img/dou.jpg" alt="profileImg">
      </div>
     
      <div class="name-job">
        <div class="profile_name">saran</div>
        <div class="job">Rapair</div>
      </div>
      
      <div class="logout">
        <a href="logout.php">
          <i class='bx bx-log-out' ></i>
        </a>
        <span class="tooltip">Log out</span>
      </div>
    </div>
  </li>
</ul>
  </div>


  
      
   

  
  
</body>
</html>
