<?php
    $localhost = 'localhost';
    $user = 'root';
    $password = '';
    $DbNAME = 'repair_system';

    $conn = mysqli_connect($localhost,$user,$password,$DbNAME);

    if(!$conn){
        echo 'ข้อมูลผิดพลาด ' . die(); 
    }
?>