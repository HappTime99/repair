<?php
    session_start();
    if(!isset($_SESSION['userid'])){
        header("Location: login.php");
    }else{
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php   
         include('include/linkcss.php');
         include('include/linkjs.php');
         include('include/connect.php');
         include('include/menu.php');
     
    ?>
    <section class="home-section">
    <i class='bx bx-menu' ></i>
    <h1 class="text-center mt-5">รายงานผลแจ้งซ่อม</h1>
    <hr>
       
    <form action="" method="post">
        <div class="container-fluid">
            
            <table class="table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>ชื่อ</th>
                        <th>นามสกุล</th>
                        <th>ชุด</th>
                        <th>รายละเอียด</th>
                        <th>สถานะ</th>
                        <th>วันที่แจ้งซ่อม</th>
                        
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $query = mysqli_query($conn,"SELECT * FROM repair");
                        while($row = mysqli_fetch_array($query)){
                    ?>
                    <tr>
                        <td><?php echo $row['id'];?></td>
                        <td><?php echo $row['fname'];?></td>
                        <td><?php echo $row['lname'];?></td>
                        <td><?php echo $row['pset'];?></td>
                        <td><?php echo $row['pdetails'];?></td> 
                        
                        <td>
                        <?php
                        $st = '' ;
                        if($row['status_id']== 0){
                            $st = "กำลังดำเนินการซ่อม";
                        }elseif ($row['status_id']==1){
                            $st = "ซ่อมเสร็จแล้ว";
                        }
                        elseif($row['status_id']==2){
                            $st = "จัดส่งทางไปรษณีย์";
                        }
                        elseif($row['status_id']==3){
                            $st = "อยู่ระหว่างการส่ง";
                        }
                        else{
                            $st = "จัดส่งเสร็จสิ้น";
                        }
                        echo $st ;
                    ?>
                        </td>
                        <td><?php echo $row['mdate'];?></td> 
                    </tr>

                </tbody>
                <?php } ?>
            </table>
        </div>
    </form>
    </section>
    <script>
    let arrow = document.querySelectorAll(".arrow");
    for (var i = 0; i < arrow.length; i++) {
        arrow[i].addEventListener("click", (e)=>{
    let arrowParent = e.target.parentElement.parentElement;//selecting main parent of arrow
    arrowParent.classList.toggle("showMenu");
        });
    }
    let sidebar = document.querySelector(".sidebar");
    let sidebarBtn = document.querySelector(".bx-menu");
    console.log(sidebarBtn);
    sidebarBtn.addEventListener("click", ()=>{
        sidebar.classList.toggle("close");
    });
    </script>
    <script>
        $(document).ready( function () {
              $('.table').DataTable();
          } );
    </script>
</body>
<?php include("include/footer.php"); ?>
</html>
<?php } ?>