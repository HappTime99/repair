<?php
    include("include/connect.php");

    class Payment{
        public function fetchdata(){
            global $conn;
            $result = mysqli_query($conn,"SELECT * FROM payment");
            return $result;
        }
        public function insert($fname,$lname,$pset,$pnumber,$payment){
            global $conn;
            $result = mysqli_query($conn,"INSERT INTO payment(fname,lname,pset,pnumber,payment)VALUES('$fname','$lname','$pset','$pnumber','$payment')");
            return $result;
        }
        public function fetchonerecord($userid){
            global $conn;
            $result = mysqli_query($conn,"SELECT * FROM payment WHERE id = '$userid'");
            return $result;
        }
        public function update($fname,$lname,$pset,$pnumber,$payment,$userid){
            global $conn; 
            $result = mysqli_query($conn,"UPDATE payment SET
            fname = '$fname',
            lname = '$lname',
            pset = '$pset',
            pnumber = '$pnumber',
            payment = '$payment'
            WHERE id = '$userid'
            ");
            return $result;
        }
        public function delete($userid){
            global $conn;
            $result = mysqli_query($conn,"DELETE FROM payment WHERE id = '$userid'");
            return $result;
        }
    }


?>