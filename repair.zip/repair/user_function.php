<?php
    include('include/connect.php');

    class User{
        public function fetchdata(){
            global $conn;
            $sql = mysqli_query($conn,"SELECT * FROM user");
            return $sql ;
        }
        public function insert($name,$surename,$ptel,$paddress,$category_user,$pusername,$ppassword){
            global $conn;
            $sql = mysqli_query($conn,"INSERT INTO user(name,surename,ptel,paddress,category_user,pusername,ppassword) 
            VALUES('$name','$surename','$ptel','$paddress','$category_user','$pusername','$ppassword')");
            return $sql;
        }
        public function fetchonerecord($userid){
            global $conn;
            $sql = mysqli_query($conn,"SELECT * FROM user WHERE id = '$userid'");
            return $sql;
        }
        public function update($name,$surename,$ptel,$paddress,$category_user,$pusername,$ppassword,$userid){
            global $conn;
            $sql = mysqli_query($conn,"UPDATE user SET
            name = '$name',
            surename = '$surename',
            ptel = '$ptel',
            paddress = '$paddress',
            category_user = '$category_user',
            pusername = '$pusername',
            ppassword = '$ppassword'
            WHERE id = '$userid'");
            return $sql;
        }
        
        public function delete($userid){
            global $conn;
            $sql = mysqli_query($conn,"DELETE FROM user WHERE id = '$userid'");
            return $sql;
        }
    }
?>