<?php
    session_start();
    if(!isset($_SESSION['userid'])){
        header("Location: login.php");
    }else{
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php 
         include('include/menu.php');
         include('include/linkjs.php');
         include('include/linkcss.php');
       
    ?>
    <section class="home-section">
    
    <i class='bx bx-menu' ></i>
    <div class="container">
        <div class="row ">
            <div class="d-flex justify-content-center">
                <div class="card mt-3 mb-3 ">
                    <img class="card-img-top" src="img/ซ่อม.jpg" alt="Card image cap"  style="width: 18rem;" >
                </div>
            </div>

            <div class="col mt-3">
                <div class="card " style="width: 18rem;">
                    <img class="card-img-top" src="img/ชุดเดรส.jpg" alt="Card image cap">
                    <div class="card-body">
                        <h5 class="card-title">ชุดเดรส</h5>
                        <p class="card-text">เสื้อด้านหลัง และด้านล่าง และเอวหลวมเก็บเข้าให้พอดีตัว.</p>
                    
                    </div>
                </div>
            </div>

            <div class="col mt-3">
                <div class="card " style="width: 18rem;">
                    <img class="card-img-top" src="img/ชุดแต่งงาน.jpg" alt="Card image cap">
                    <div class="card-body ">
                        <h5 class="card-title">ชุดแต่งงาน</h5>
                        <p class="card-text">แก้ชุดแต่งงานเสื้อบางเห็นทรงอก แก้ชุดโดยวิธีแทรกผ้าด้านในเพื่อบังทรงอก.</p>
                    
                    </div>
                </div>
            </div>

            <div class="col mt-3">
                <div class="card " style="width: 18rem; ">
                    <img class="card-img-top" src="img/ชุดไทย.jpg" alt="Card image cap">
                    <div class="card-body ">
                        <h5 class="card-title">ชุดไทย</h5>
                        <p class="card-text">เสื้อช่วงบน และกระโปรงท่อนล่างหลวม เก็บเข้าให้พอดีตัวกับผู้สวมใส่.</p>
                    
                    </div>
                </div>
            </div>
        
       
    </div>
    </section>
    <script>
  let arrow = document.querySelectorAll(".arrow");
  for (var i = 0; i < arrow.length; i++) {
    arrow[i].addEventListener("click", (e)=>{
   let arrowParent = e.target.parentElement.parentElement;//selecting main parent of arrow
   arrowParent.classList.toggle("showMenu");
    });
  }
  let sidebar = document.querySelector(".sidebar");
  let sidebarBtn = document.querySelector(".bx-menu");
  console.log(sidebarBtn);
  sidebarBtn.addEventListener("click", ()=>{
    sidebar.classList.toggle("close");
  });
  </script>
</body>
<?php include("include/footer.php"); ?>
</html>
<?php } ?>