<?php
    include('include/connect.php');

    class Parcel {
        public function fetchdata(){
            global $conn;
            $result = mysqli_query($conn,"SELECT * FROM parcel");
            return $result;
        }
        public function insert($fname,$lname,$ptel,$paddress){
            global $conn;
            $result = mysqli_query($conn,"INSERT INTO parcel(fname,lname,ptel,paddress) VALUES('$fname','$lname','$ptel','$paddress')");
            return $result ;
        }
        public function fetchonerecord($userid){
            global $conn;
            $result = mysqli_query($conn,"SELECT * FROM parcel WHERE parcel_id ='$userid'");
            return $result;
        }

         public function update($fname,$lname,$ptel,$paddress,$userid){
            global $conn;
            $result = mysqli_query($conn,"UPDATE parcel SET 
            fname = '$fname',
            lname = '$lname',
            ptel = '$ptel',
            paddress = '$paddress'
            WHERE parcel_id = '$userid'");
            return $result;
         }
         public function delete($userid){
             global $conn;
             $result = mysqli_query($conn,"DELETE FROM parcel WHERE parcel_id = '$userid'");
             return $result;
         }
    }
?>