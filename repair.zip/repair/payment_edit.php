<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
        include('include/menu.php');
        include('include/linkjs.php');
        include('include/linkcss.php');
        include('payment_function.php');
        //update
        $update = new Payment();
        if(isset($_POST['update'])){
            $userid = $_GET['id'];
            $fname = $_POST['fname'];
            $lname = $_POST['lname'];
            $pset = $_POST['pset'];
            $pnumber = $_POST['pnumber'];
            $payment = $_POST['payment'];

            $sql = $update->update($fname,$lname,$pset,$pnumber,$payment,$userid);
            if($sql) {
                echo "<script>";
                echo "Swal.fire({
                    icon: 'success',
                    title: 'แก้ไขข้อมูลเสร็จเรียบร้อยแล้วครับ',
                    showConfirmButton: false,
                    timer: 2000
                }).then((result ) => {
                    if(result.isDismissed){
                        window.location.href = 'payment_view.php';
                    }
                  });";
                echo "</script>";
            }else{
                echo "<script>";
                echo "Swal.fire({
                    icon: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong!',
                  });";
                echo "</script>";
            }
        }
        
        
        $userid = $_GET['id'];
        $fetchonerecord = new Payment();
        $sql = $fetchonerecord->fetchonerecord($userid);
        if($row = mysqli_fetch_array($sql)){
            
    ?>
     <section class="home-section">
    <i class='bx bx-menu' ></i>
    <h1 class="text-center mt-3">แก้ไขข้อมูลลูกค้า</h1>
    <hr>
   
    <form action="" method="post">
        <div class="container">
            <div class="mb-4 row">
                <label for="" class="col-sm-2 col-form-label">ชื่อ</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" name="fname"  placeholder="กรุณากรอกชื่อ" value="<?php echo $row['fname']; ?>" require>
                </div>
            </div>

            <div class="mb-4 row">
                <label for="" class="col-sm-2 col-form-label">นามสกุล</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" name="lname" placeholder="กรุณากรอกนามสกุล" value="<?php echo $row['lname'];?>"   require>
                </div>
            </div>

            <div class="mb-4 row">
                <label for="" class="col-sm-2 col-form-label">ชุด</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" name="pset" placeholder="กรุณากรอกชุด" value="<?php echo $row['pset'];?>"   require>
                </div>
            </div>

            <div class="mb-4 row">
                <label for="" class="col-sm-2 col-form-label">จำนวน</label>
                <div class="col-sm-10">
                <input type="number" class="form-control" name="pnumber" placeholder="กรุณากรอกจำนวน" value="<?php echo $row['pnumber'];?>"   require>
                </div>
            </div>

            <div class="mb-4 row">
                <label for="" class="col-sm-2 col-form-label">ค่าบริการ</label>
                <div class="col-sm-10">
                <input type="number" class="form-control" name="payment" placeholder="กรุณากรอกค่าบริการ" value="<?php echo $row['payment'];?>"   require>
                </div>
            </div>

        

            <div class="text-center">
                <button type="submit" class="btn btn-success" name="update" >อัพเดต</button>
                <a href="payment_view.php" class="btn btn-secondary">ย้อนกลับ</a>
            </div>
    
        </div>
        <?php } ?>
        
    </form>

    </section>

    <script>
  let arrow = document.querySelectorAll(".arrow");
  for (var i = 0; i < arrow.length; i++) {
    arrow[i].addEventListener("click", (e)=>{
   let arrowParent = e.target.parentElement.parentElement;//selecting main parent of arrow
   arrowParent.classList.toggle("showMenu");
    });
  }
  let sidebar = document.querySelector(".sidebar");
  let sidebarBtn = document.querySelector(".bx-menu");
  console.log(sidebarBtn);
  sidebarBtn.addEventListener("click", ()=>{
    sidebar.classList.toggle("close");
  });
  </script>

</body>

<?php include("include/footer.php"); ?>
</html>