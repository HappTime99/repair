<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
        include('include/menu.php');
        include('include/linkjs.php');
        include('include/linkcss.php');
        include('user_function.php');
        //update
        $updatedata = new User();
        if(isset($_POST['update'])){
            $userid = $_GET['id'];
            $name = $_POST['name'];
            $surename = $_POST['surename'];
            $ptel = $_POST['ptel'];
            $paddress = $_POST['paddress'];
            $category_user = $_POST['category_user'];
            $pusername = $_POST['pusername'];
            $ppassword = md5($_POST['ppassword']);
           

            $sql = $updatedata->update($name,$surename,$ptel,$paddress,$category_user,$pusername,$ppassword,$userid);
            //echo $sql ; exit();
            if($sql) {
                echo "<script>";
                echo "Swal.fire({
                    icon: 'success',
                    title: 'อัพเดตข้อมูลเสร็จเรียบร้อยแล้วครับ',
                    showConfirmButton: false,
                    timer: 2000
                }).then((result ) => {
                    if(result.isDismissed){
                        window.location.href = 'user_view.php';
                    }
                  });";
                echo "</script>";
            }else{
                echo "<script>";
                echo "Swal.fire({
                    icon: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong!',
                  });";
                echo "</script>";
            }
        }
        
        
        $userid = $_GET['id'];
        $fetchonerecord = new User();
        $sql = $fetchonerecord->fetchonerecord($userid);
        if(mysqli_num_rows($sql)==1){
            $row = mysqli_fetch_array($sql)
    ?>
    <section class="home-section">
    <i class='bx bx-menu' ></i>
    <h1 class="text-center mt-3">แก้ไขข้อมูลผู้ใช้งาน</h1>
    <hr>
    
    <form action="" method="post">
        <div class="container">
            <div class="mb-4 row">
                    <label for="" class="col-sm-2 col-form-label">ชื่อ</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" name="name" value="<?php echo $row['name'];?>"  placeholder="กรุณากรอกชื่อ" require>
                    </div>
                </div>

                <div class="mb-4 row">
                    <label for="" class="col-sm-2 col-form-label">นามสกุล</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" name="surename" placeholder="กรุณากรอกนามสกุล" value="<?php echo $row['surename'];?>"   require>
                    </div>
                </div>

                <div class="mb-4 row">
                    <label for="" class="col-sm-2 col-form-label">เบอร์โทร</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" name="ptel" placeholder="กรุณากรอกเบอร์โทร" value="<?php echo $row['ptel'];?>"   require>
                    </div>
                </div>

                <div class="mb-4 row">
                    <label for="" class="col-sm-2 col-form-label">ที่อยุ่</label>
                    <div class="col-sm-10">
                    <textarea  rows="4" name="paddress" class="form-control" placeholder="กรุณากรอกที่อยู่" ><?php echo $row['paddress'];?></textarea>
                    </div>
                </div>

                <div class="mb-4 row">
                    <label for="" class="col-sm-2 col-form-label">ประเภทผู้ใช้งาน</label>
                    <div class="col-sm-10">
                        <select name="category_user" >
                            <option value="0">EMPLOYEE</option>
                            <option value="1" >ADMIN</option>
                        </select>
                    </div>
                </div>

                <div class="mb-4 row">
                    <label for="" class="col-sm-2 col-form-label">username</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" name="pusername" placeholder="กรุณากรอกชื่อผู้ใช้งาน" value="<?php echo $row['pusername'];?>"   require>
                    </div>
                </div>

                <div class="mb-4 row">
                    <label for="" class="col-sm-2 col-form-label">username</label>
                    <div class="col-sm-10">
                        <input type="password" class="form-control" name="ppassword" placeholder="กรุณากรอกรหัสผู้ใช้งาน" value="<?php echo $row['pusername'];?>"   require>
                    </div>
                </div>

                

            <div class="text-center">
                <button type="submit" class="btn btn-success" name="update" >อัพเดต</button>
                <a href="user_view.php" class="btn btn-secondary">ย้อนกลับ</a>
            </div>
    
        </div>
        <?php } ?>
    </form>
    </section>
        <script>
    let arrow = document.querySelectorAll(".arrow");
    for (var i = 0; i < arrow.length; i++) {
        arrow[i].addEventListener("click", (e)=>{
    let arrowParent = e.target.parentElement.parentElement;//selecting main parent of arrow
    arrowParent.classList.toggle("showMenu");
        });
    }
    let sidebar = document.querySelector(".sidebar");
    let sidebarBtn = document.querySelector(".bx-menu");
    console.log(sidebarBtn);
    sidebarBtn.addEventListener("click", ()=>{
        sidebar.classList.toggle("close");
    });
    </script>
</body>
<?php include("include/footer.php"); ?>
</html>