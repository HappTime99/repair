<?php 
	session_start(); 

?>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->


<!DOCTYPE html>
<link rel="stylesheet" href="login.css">
<html>
    
<head>
	<title>My Awesome Login Page</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.1/css/all.css" integrity="sha384-gfdkjb5BdAXd+lj+gudLWI+BXq4IuLW5IT+brZEZsLFm++aCMlF1V92rMkPaX4PP" crossorigin="anonymous">
</head>
<!--Coded with love by Mutiullah Samim-->
<body>
    <?php
        include('include/linkjs.php');
        include('include/linkcss.php');
        include('include/menu.php');
       
?>
<section class="home-section">
    
	<i class='bx bx-menu' ></i>
		

	<div class="container h-100">
		<div class="d-flex justify-content-center h-100">
			<div class="user_card">
				<div class="d-flex justify-content-center">
					<div class="brand_logo_container">
						<img src="img/dou.jpg" class="brand_logo" alt="Logo">
					</div>
					
				</div><br>


				<div class="d-flex justify-content-center form_container">
					
					<form action="checklogin.php" method="POST">
							<?php 
							if(isset($_SESSION['prompt'])) {
								echo "<div class='alert alert-success'>".$_SESSION['prompt']."</div>";
							}

							if(isset($_SESSION['errprompt'])) {
								echo "<div class='alert alert-danger'>".$_SESSION['errprompt']."</div>";
							}
							?>
						<div class="input-group mb-3">
							<div class="input-group-append">
								<span class="input-group-text"><i class="fas fa-user"></i></span>
							</div>
							<input type="text" name="pusername" class="form-control input_user" value="" placeholder="username">
						</div>
						<div class="input-group mb-2">
							<div class="input-group-append">
								<span class="input-group-text"><i class="fas fa-key"></i></span>
							</div>
							<input type="password" name="ppassword" class="form-control input_pass" value="" placeholder="password">
						</div>
						
							<div class="d-flex justify-content-center mt-3 login_container">
						<input type="submit" class="btn btn-success "   value="login">
				   </div>
					</form>
				</div>
		
				
			</div>
		</div>
	</div>
				
	</section>

	<script>
  let arrow = document.querySelectorAll(".arrow");
  for (var i = 0; i < arrow.length; i++) {
    arrow[i].addEventListener("click", (e)=>{
   let arrowParent = e.target.parentElement.parentElement;//selecting main parent of arrow
   arrowParent.classList.toggle("showMenu");
    });
  }
  let sidebar = document.querySelector(".sidebar");
  let sidebarBtn = document.querySelector(".bx-menu");
  console.log(sidebarBtn);
  sidebarBtn.addEventListener("click", ()=>{
    sidebar.classList.toggle("close");
  });
  </script>


</body>
</html>
<?php



unset($_SESSION['prompt']);
unset($_SESSION['errprompt']);



?>

