<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php   
        include('include/menu.php');
        include('include/linkjs.php');
        include('include/linkcss.php');
        include('repair_function.php');
        
        //insert
        if(isset($_POST['insert'])){
            $fname = $_POST['fname'];
            $lname = $_POST['lname'];
            $pset = $_POST['pset'];
            $pdetails = $_POST['pdetails'];
            $status_id = $_POST['status_id'];
        
            $insert = new Repair();
            $sql = $insert->insert($fname,$lname,$pset,$pdetails,$status_id);
            //echo $sql ; exit();
            if($sql) {
                echo "<script>";
                echo "Swal.fire({
                    icon: 'success',
                    title: 'เพิ่มข้อมูลเสร็จเรียบร้อยแล้วครับ',
                    showConfirmButton: false,
                    timer: 2000
                }).then((result ) => {
                    if(result.isDismissed){
                        window.location.href = 'repair_view.php';
                    }
                  });";
                echo "</script>";
            }else{
                echo "<script>";
                echo "Swal.fire({
                    icon: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong!',
                  });";
                echo "</script>";
            }        
        }

    ?>
    <section class="home-section">
    <i class='bx bx-menu' ></i>
    <h1 class="text-center mt-3">ข้อมูลแจ้งซ่อม</h1>
    <hr>
    
    <form action="" method="post">
        <div class="container">
            <div class="mb-4 row">
                <label for="" class="col-sm-2 col-form-label">ชื่อผู้แจ้ง</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" name="fname"  placeholder="กรุณากรอกชื่อผู้แจ้ง" require>
                </div>
            </div>

            <div class="mb-4 row">
                <label for="" class="col-sm-2 col-form-label">นามสกุลผู้แจ้ง</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" name="lname" placeholder="กรุณากรอกนามสกุลผู้แจ้ง"   require>
                </div>
            </div>

            <div class="mb-4 row">
                <label for="" class="col-sm-2 col-form-label">ชุดที่แจ้ง</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" name="pset" placeholder="กรุณากรอกชุดผู้แจ้ง"   require>
                </div>
            </div>

            <div class="mb-4 row">
                <label for="" class="col-sm-2 col-form-label">รายละเอียด</label>
                <div class="col-sm-10">
                   <textarea  rows="4" name="pdetails" class="form-control" placeholder="กรุณากรอกรายละเอียด" ></textarea>
                </div>
            </div>

            <div class="mb-4 row">
                <label for="" class="col-sm-2 col-form-label">สถานะ</label>
                <div class="col-sm-10">
                    <select name="status_id" >
                        <option value="0">กำลังดำเนินการซ่อม</option>
                        <option value="1" >ซ่อมเสร็จแล้ว</option>
                        <option value="2" >จัดส่งทางไปรษณีย์</option>
                        <option value="3" >อยู่ระหว่างการส่ง</option>
                        <option value="4" >จัดส่งเสร็จสิ้น</option>
                    </select>
                </div>
            </div>

            <div class="text-center">
                <button type="submit" class="btn btn-success" name="insert" >แจ้งซ่อม</button>
                <a href="repair_view.php" class="btn btn-secondary">ย้อนกลับ</a>
            </div>
    
        </div>
    </form>

   </section>

    <script>
    let arrow = document.querySelectorAll(".arrow");
    for (var i = 0; i < arrow.length; i++) {
        arrow[i].addEventListener("click", (e)=>{
    let arrowParent = e.target.parentElement.parentElement;//selecting main parent of arrow
    arrowParent.classList.toggle("showMenu");
        });
    }
    let sidebar = document.querySelector(".sidebar");
    let sidebarBtn = document.querySelector(".bx-menu");
    console.log(sidebarBtn);
    sidebarBtn.addEventListener("click", ()=>{
        sidebar.classList.toggle("close");
    });
    </script>
</body>
<?php include("include/footer.php"); ?>
</html>