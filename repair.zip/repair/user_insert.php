<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php   
        include('include/menu.php');
        include('include/linkjs.php');
        include('include/linkcss.php');
        include('user_function.php');
        
        //insert
        if(isset($_POST['insert'])){
            $name = $_POST['name'];
            $surename = $_POST['surename'];
            $ptel = $_POST['ptel'];
            $paddress = $_POST['paddress'];
            $category_user = $_POST['category_user'];
            $pusername = $_POST['pusername'];
            $ppassword = md5($_POST['ppassword']);
        
            $insert = new User();
            $sql = $insert->insert($name,$surename,$ptel,$paddress,$category_user,$pusername,$ppassword);
            //echo $sql ; exit();
            if($sql) {
                echo "<script>";
                echo "Swal.fire({
                    icon: 'success',
                    title: 'เพิ่มข้อมูลเสร็จเรียบร้อยแล้วครับ',
                    showConfirmButton: false,
                    timer: 2000
                }).then((result ) => {
                    if(result.isDismissed){
                        window.location.href = 'user_view.php';
                    }
                  });";
                echo "</script>";
            }else{
                echo "<script>";
                echo "Swal.fire({
                    icon: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong!',
                  });";
                echo "</script>";
            }       
        }

    ?>
    <section class="home-section">
    <i class='bx bx-menu' ></i>
    <h1 class="text-center mt-3">ข้อมูลผู้ใช้งาน</h1>
    <hr>
    
    <form action="" method="post">
        <div class="container">
            <div class="mb-4 row">
                <label for="" class="col-sm-2 col-form-label">ชื่อ</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" name="name"  placeholder="กรุณากรอกชื่อ" require>
                </div>
            </div>

            <div class="mb-4 row">
                <label for="" class="col-sm-2 col-form-label">นามสกุล</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" name="surename" placeholder="กรุณากรอกนามสกุล"   require>
                </div>
            </div>

            <div class="mb-4 row">
                <label for="" class="col-sm-2 col-form-label">เบอร์โทร</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" name="ptel" placeholder="กรุณากรอกเบอร์โทร"   require>
                </div>
            </div>

            <div class="mb-4 row">
                <label for="" class="col-sm-2 col-form-label">ที่อยุ่</label>
                <div class="col-sm-10">
                   <textarea  rows="4" name="paddress" class="form-control" placeholder="กรุณากรอกที่อยู่" ></textarea>
                </div>
            </div>

            <div class="mb-4 row">
                <label for="" class="col-sm-2 col-form-label">ประเภทผู้ใช้งาน</label>
                <div class="col-sm-10">
                    <select name="category_user" >
                        <option value="0">EMPLOYEE</option>
                        <option value="1" >ADMIN</option>
                    </select>
                </div>
            </div>

            <div class="mb-4 row">
                <label for="" class="col-sm-2 col-form-label">ชื่อผู้ใช้งาน</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" name="pusername" placeholder="กรุณากรอกชื่อผู้ใช้งาน"   require>
                </div>
            </div>

            <div class="mb-4 row">
                <label for="" class="col-sm-2 col-form-label">รหัสผู้ใช้งาน</label>
                <div class="col-sm-10">
                    <input type="password" class="form-control" name="ppassword" placeholder="กรุณากรอกเบอร์โทร"   require>
                </div>
            </div>

            <div class="text-center">
                <button type="submit" class="btn btn-success" name="insert" >เพิ่มผู้ใช้งาน</button>
                <a href="user_view.php" class="btn btn-secondary">ย้อนกลับ</a>
            </div>
    
        </div>
    </form>

    </section>
    <script>
  let arrow = document.querySelectorAll(".arrow");
  for (var i = 0; i < arrow.length; i++) {
    arrow[i].addEventListener("click", (e)=>{
   let arrowParent = e.target.parentElement.parentElement;//selecting main parent of arrow
   arrowParent.classList.toggle("showMenu");
    });
  }
  let sidebar = document.querySelector(".sidebar");
  let sidebarBtn = document.querySelector(".bx-menu");
  console.log(sidebarBtn);
  sidebarBtn.addEventListener("click", ()=>{
    sidebar.classList.toggle("close");
  });
  </script>
    
</body>
<?php include("include/footer.php"); ?>
</html>