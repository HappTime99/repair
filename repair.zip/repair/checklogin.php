<?php
    session_start();
    if(isset($_POST['pusername'])){
        include("include/connect.php");
        $username = mysqli_real_escape_string($conn,$_POST['pusername']);
        $ppassword = mysqli_real_escape_string($conn,$_POST['ppassword']);
        $pword = md5($ppassword);

        $sql = mysqli_query($conn,"SELECT * FROM user WHERE pusername = '$username' AND ppassword = '$pword'");
        
        if(mysqli_num_rows($sql)==1){

            $row = mysqli_fetch_array($sql);
            $_SESSION['userid'] = $row['id'];
           
            $_SESSION['category_user'] = $row['category_user'];
            if($_SESSION['category_user']== 0 || $_SESSION['category_user']==1){
                header("Location: index.php");
            }
        }else {
            $_SESSION['errprompt'] = "Wrong username or password.";
            header("Location: login.php");
        }
    }else{
        header("Location: login.php");
    }

?>