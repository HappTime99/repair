<?php
    session_start();
    if(!isset($_SESSION['userid'])){
        header("Location: login.php");
    }else{
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php   
         include('include/linkcss.php');
         include('include/linkjs.php');
         include('include/connect.php');
         include('include/menu.php');
     
    ?>
    <section class="home-section">
    <i class='bx bx-menu' ></i>
    <div class="container-fluid">
    <h1 class="text-center mt-5">รายงานผลผู้ใช้งาน</h1>
    <hr>
        
    <form action="" method="post">
        
            
            <table class="table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>ชื่อ</th>
                        <th>นามสกุล</th>
                        <th>เบอร์โทร</th>
                        <th>ที่อยู่</th>
                        <th>ชื่อผู้ใช้งาน</th>
                        <th>รหัสผ่านผู้ใช้งาน</th>
                        <th>สถานะ</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $query = mysqli_query($conn,"SELECT * FROM user");
                        while($row = mysqli_fetch_array($query)){
                    ?>
                    <tr>
                        <td><?php echo $row['id'];?></td>
                        <td><?php echo $row['name'];?></td>
                        <td><?php echo $row['surename'];?></td>
                        <td><?php echo $row['ptel'];?></td>
                        <td><?php echo $row['paddress'];?></td>
                        <td><?php echo $row['pusername'];?></td>
                        <td><?php echo $row['ppassword'];?></td>
                        
                        <?php
                            $st = '';
                            if($row['category_user'] == 0 ){
                                $st = "EMPLOYEE";
                            }else{
                                $st = "ADMIN";
                            }
                            echo '<td>' . $st . '</td>' ;
                        ?>
                    </tr>

                </tbody>
                <?php } ?>
            </table>
        </div>
    </form>
    </section>
    <script>
    let arrow = document.querySelectorAll(".arrow");
    for (var i = 0; i < arrow.length; i++) {
        arrow[i].addEventListener("click", (e)=>{
    let arrowParent = e.target.parentElement.parentElement;//selecting main parent of arrow
    arrowParent.classList.toggle("showMenu");
        });
    }
    let sidebar = document.querySelector(".sidebar");
    let sidebarBtn = document.querySelector(".bx-menu");
    console.log(sidebarBtn);
    sidebarBtn.addEventListener("click", ()=>{
        sidebar.classList.toggle("close");
    });
    </script>
    <script>
        $(document).ready( function () {
              $('.table').DataTable();
          } );
    </script>
</body>
<?php include("include/footer.php"); ?>
</html>
<?php } ?>